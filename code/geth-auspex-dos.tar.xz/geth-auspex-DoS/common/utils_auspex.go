package common

import (
	"github.com/ethereum/go-ethereum/auspex"
)

var GlobalAuspexObj *auspex.SManager